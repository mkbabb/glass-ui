# Ninety-two-row challenge matrix

Pinned authority: Glass `562db5c7429373220a4f1ec4e67470d65fcdbd91`.

This is the row-grain receipt the aggregate passes lacked. It is intentionally RED: `I/—/—` means
the row was inventoried but did not receive a row-specific second or third adjudication. `D/R/R`
means a defect was discovered and survived two challenges; it still owes the exact-candidate
post-freeze Sol audit. No source-touched or banked row becomes DONE here.

Class codes: `ST` source-touched, `U` untouched, `AP` ASK-parked, `AC` authority-conflict park, `PU`
unrouteable park, `DH` dependency-held, `BE` banked evidence, `(s)` slice only. Pass codes: `I`
inventory, `D` direct finding, `R` retained, `M` merged/narrowed, `F` falsified/corrected, `H` hold
re-proved, `B` bank re-proved, `A` candidate amendment, `—` no row-specific adjudication.

## BJ band waves (48)

| # | row | class | pre-freeze P1/P2/P3 | adjudication / debt |
| ---: | --- | --- | --- | --- |
| 1 | `BJ.W-A11Y-STATE` | U | I/—/— | No bespoke later challenge. |
| 2 | `BJ.W-A11Y-LINKAGE` | ST+DH+AP(s) | I/—/A | A–D touched; E/F wait MATERIAL W4; ASK-17 and G6 compact floor remain. |
| 3 | `BJ.W-A11Y-CONTRAST` | U+DH | I/—/— | W3-A/C depend on ASK-25/FM W4. |
| 4 | `BJ.W-A11Y-LIVE-REGIONS` | U | I/—/— | No bespoke later challenge. |
| 5 | `BJ.W-A11Y-ROVING-RULINGS` | ST+DH | I/—/A | W5-C touched at re-pin; W5-B waits GF-DOCK W3. |
| 6 | `BJ.W-COLO-1` | ST | I/—/— | Historical GESTALT coverage only. |
| 7 | `BJ.W-COLO-2` | U+DH | I/—/— | 8.0 `./sidebar` break and consumer relay remain. |
| 8 | `BJ.W-COLO-3` | U | D/R/R | DAG true-up: 535 modules, 1,297 edges, 9 all-edge/2 runtime SCCs. |
| 9 | `BJ.W-DOC-TRUTHUP` | ST+BE | I/—/— | Banked close note; no current three-pass proof. |
| 10 | `BJ.W-TOAST-DIALOG-PARITY` | ST | I/—/— | Later touched row outside first-ten historical audit. |
| 11 | `BJ.W-PROGRESS-RIM-REPLACE` | ST+DH | D/R/R | Explicit 8.0 break retained; API diff/migration/census owed. |
| 12 | `BJ.W-FEEDBACK-MOTION-TUNE` | ST | I/—/— | Touched, no bespoke later challenge. |
| 13 | `BJ.W-ALERT-IDIOM` | AP-25 | I/H/H | User identity ruling feeds A11Y W3-C. |
| 14 | `BJ.W-IDLE-BREATH` | AP-27 | I/H/H | Hard block remains; no band pre-decides. |
| 15 | `BJ.W-PAGER-DOT-MORPH` | ST+BE | I/—/— | Historical proof only; survivor refinement remains. |
| 16 | `BJ.W-SHEET-MOTION-DEBT` | U+DH | I/—/— | Coordinates with MATERIAL W3(b). |
| 17 | `BJ.W-GATE-COLLAPSE` | U+DH | D/—/R | Boot split amended; count guard still closes last. |
| 18 | `BJ.W-PIXEL-FLOOR-CI` | ST+BE | I/—/— | ASK-24 fired/ruled; no current row-specific double challenge. |
| 19 | `BJ.W-STATIC-HYGIENE` | ST+BE | I/—/— | Historical first-ten coverage only. |
| 20 | `BJ.W-RAMP-RESET` | U+DH | I/—/— | Atomic with MATERIAL W6. |
| 21 | `BJ.W-RADIUS-ROLE` | U | I/—/— | No bespoke later challenge. |
| 22 | `BJ.W-BLUR-LADDER` | U | D/R/A | G3 narrowed to source plumbing + real-underlay compositing. |
| 23 | `BJ.W-GRADED-BACKDROP-JUDGE` | U | I/—/— | ASK-26 is a paint-lane veto window. |
| 24 | `BJ.W-TRACK-DRY` | U | I/—/— | Prerequisite for A11Y W2-E/F. |
| 25 | `BJ.W-ARISTOTLE-PROPORTION` | U | I/—/— | No bespoke later challenge. |
| 26 | `BJ.W-TYPE-CODEMOD` | U+DH | I/—/— | Atomic with GATES W4. |
| 27 | `BJ.W-CSS-CLOSURE-RESTORE` | U | I/—/R | Shipped orphan-CSS defect retained. |
| 28 | `BJ.W-REFRACT-LATCH` | U | I/—/R | Shipped WebKit gate-lie retained; video proof owed. |
| 29 | `BJ.W-BOOT-DIET` | ST | D/—/R | Source cut retained; normal/fresh-dist gate split added. |
| 30 | `BJ.W-SHELL-FIELD-GOVERN` | U | D/R/A | G4 expanded to metadata, handler handoff, and eviction. |
| 31 | `BJ.W-DEFERRED-PAINT` | U | I/—/— | No bespoke later challenge. |
| 32 | `BJ.W-ROUTE-PENDING` | U+DH | I/—/— | Consumes STORY W7. |
| 33 | `BJ.W-REDUCE-PROPDIET` | ST+BE | I/—/— | Touched/banked, not current-close proof. |
| 34 | `BJ.W-REDUCE-CARD` | U | I/—/— | No bespoke later challenge. |
| 35 | `BJ.W-REDUCE-DELETE` | ST+AP(s) | I/—/— | Clean members touched; ASK-3/11/13 slices remain. |
| 36 | `BJ.W-REDUCE-CROSSREPO-GATED` | AP-1/2 | I/H/H | Valid family-B/user park. |
| 37 | `BJ.W-REDUCE-TIMELINE` | AP-7 | I/H/H | User-gated collapse shape. |
| 38 | `BJ.W-REDUCE-FEEDBACK-MARK` | ST+BE | I/—/— | Executed with W3; no current three-pass proof. |
| 39 | `BJ.W-REDUCE-OVERLAY-SURFACE` | PU | I/H/H | Nonexistent “ASK A4”; needs new ASK or lead disposition. |
| 40 | `BJ.W-REDUCE-GOO-ENGINE` | ST+AP(s) | I/—/— | Deck executed; carousel half under ASK-6. |
| 41 | `BJ.W-REDUCE-SCROLL-REVEAL` | AP-4 | D/M/R | Owns 13-section/9-heading/4-port scroll reduction. |
| 42 | `BJ.W-STORY-TAXONOMY` | AP-13 | D/R/F | Hierarchy retained; parsed truth is 269/four bindings. |
| 43 | `BJ.W-STORY-COPY-CANON` | ST | D/M/R | Tail narrowed to outcome/choice/use. |
| 44 | `BJ.W-CONFIGURATOR-STD` | ST | I/—/— | Touched, no bespoke later challenge. |
| 45 | `BJ.W-WIDTH-HIERARCHY-TRUTH` | U | D/R/F | Rollout owner retained; 269/four correction. |
| 46 | `BJ.W-PREVIEW-CARD` | U | D/F/A | Shared three-consumer scope; Optical Bench flow amended. |
| 47 | `BJ.W-RESPONSIVE-AUDIT` | ST | D/R/R | Overflow-only 0/99 false-green reopened. |
| 48 | `BJ.W-STORY-TRANSITIONS` | U+DH | D/—/A | Route initiation classes/ascent pairing amended; before PERF W4. |

## Greenfields (35)

| # | row | class | pre-freeze P1/P2/P3 | adjudication / debt |
| ---: | --- | --- | --- | --- |
| 49 | GF-DOCK W0 contract lock | U | I/—/— | No bespoke later challenge. |
| 50 | GF-DOCK W1 census/evidence | U | I/—/— | No bespoke later challenge. |
| 51 | GF-DOCK W2 detent engine | U+DH | I/—/— | Consumes IOS W2. |
| 52 | GF-DOCK W3 tap/reach/keyboard | AP-17 | D/F/R | Narrowed to current-item exposure; ASK-17 remains. |
| 53 | GF-DOCK W4 selection lens | AP-15 | I/H/H | Refraction identity call remains. |
| 54 | GF-DOCK W5 shape/radius | U | I/—/— | No bespoke later challenge. |
| 55 | GF-DOCK W6 transition/no-shift | U+DH | I/—/— | Must reconcile STORY W7. |
| 56 | GF-DOCK W7 fission | AP-14 | I/H/H | Parked both ways. |
| 57 | GF-DOCK W8 posture/continuity | U | I/—/— | No bespoke later challenge. |
| 58 | GF-DOCK W9 consumer/final | AP-16+DH | D/D/A | Safe-frame demoted to actual-tree/posture investigation; waits Atlas ScrollRoot. |
| 59 | GF-HANDMARK W0 contract | U | I/—/— | First-principles authority exists; no later challenge. |
| 60 | GF-HANDMARK W1 voice | U | I/—/— | No bespoke later challenge. |
| 61 | GF-HANDMARK W2 surface | U | I/F/— | Generic nested-frame rider refuted. |
| 62 | GF-HANDMARK W3 choreography | U | I/—/— | No bespoke later challenge. |
| 63 | GF-HANDMARK W4 story | U | I/F/— | Preview-card finding does not belong here. |
| 64 | GF-HANDMARK W5 final | U | I/F/— | No frame rider; otherwise unchallenged. |
| 65 | GF-AURORA W0 contract | U | I/—/— | No bespoke later challenge. |
| 66 | GF-AURORA W1 Van Gogh | U | I/—/— | No bespoke later challenge. |
| 67 | GF-AURORA W2 oil-pastel | U | I/—/— | No bespoke later challenge. |
| 68 | GF-AURORA W3 crayon | AC-20 | I/—/A | Senior spec says CUT; owner mark absent, so authority conflict remains. |
| 69 | GF-AURORA W4 oil | U+DH | I/—/— | W0 budget/paint chooses PORT/REAUTHOR/KILL. |
| 70 | GF-AURORA W5 register/axes/rot | AP-28(s)+DH | I/—/A | DUSK/DAWN user call added; painterly half waits W1–W4. |
| 71 | GF-AURORA W6 V-A95 | U+DH | I/—/F | Separated from clipping; runs after modes. |
| 72 | GF-AURORA W7 final | U+DH | D/R/F | Owns clipping cure; STORY W6 owns audit. |
| 73 | GF-BLOB W0 contract | AP-29(s) | I/—/A | Default decision now has correct options. |
| 74 | GF-BLOB W-SHADOW | U | I/—/— | No bespoke later challenge. |
| 75 | GF-BLOB W-STREAK | U | I/—/— | No bespoke later challenge. |
| 76 | GF-BLOB W-IDENT | AP-29(s) | I/—/A | Chrome premise refuted; default still owner-gated. |
| 77 | GF-BLOB W-SHOW | AP-29(s) | I/—/A | Default adoption slice waits ASK-29. |
| 78 | GF-BLOB W-ALIVE | U | I/—/— | No bespoke later challenge. |
| 79 | GF-BLOB W-MOOD | AP-30(s) | I/—/A | Only thinking slice parked. |
| 80 | GF-BLOB W-REACT | AP-31(s) | I/—/A | Only grab slice parked; repulsion proceeds. |
| 81 | GF-BLOB W-HITTEST | U+DH | I/—/— | Ordered at/after W-SHOW. |
| 82 | GF-BLOB W-TOPOLOGY | U | I/—/— | No bespoke later challenge. |
| 83 | GF-BLOB W-FINAL | U+DH+AP-29(s) | I/—/A | W-FINAL owns value.js relay; no WGPU-delete park. |

## IOS27-MICRO and BI (9)

| # | row | class | pre-freeze P1/P2/P3 | adjudication / debt |
| ---: | --- | --- | --- | --- |
| 84 | IOS W-0 paint drain | BE | I/—/F+B | Omission refuted; 6 PASS/1 DEFER/0 FAIL, tail in W7. |
| 85 | IOS W-1 register/token | ST | I/—/— | Source landed; dock DELTA still owed. |
| 86 | IOS W-2 spine-conductor | U | I/—/— | GF-DOCK W2 dependency. |
| 87 | IOS W-3 F4 family | U | I/—/— | No bespoke later challenge. |
| 88 | IOS W-4 F5 family | U+DH | I/—/— | Kernel/shared-lens sequencing remains. |
| 89 | IOS W-5 novelty adoptions | U | D/R/A | G5 now single-render decorative reservation; V-PERCH unparked. |
| 90 | IOS W-6 engagement/breath | U+DH | I/—/— | Depends on register/canon shipping. |
| 91 | IOS W-7 remainders | U+DH | I/—/R | Owns W-0 deferred tail/re-entry. |
| 92 | `BI.W-ENGAGE-AFFORD` | U+DH | I/—/— | SPEC-only; rebase, scalar unification, fresh Sol paint judgment owed. |

## Consequence

Candidate 1 cannot inherit a “three whole-tranche challenges” claim from the aggregate passes. Before
freeze closure, three independent Sol x-high audits must each walk all 92 rows from this matrix and
record a row-level verdict. Any amendment resets the exact-candidate digest; the final post-freeze
challenge and two consecutive clean audits still apply afterward.

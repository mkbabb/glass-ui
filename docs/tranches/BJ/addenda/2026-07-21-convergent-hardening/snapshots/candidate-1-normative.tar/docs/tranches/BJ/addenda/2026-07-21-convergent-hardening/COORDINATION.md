# Live Q / Atlas / keyframes coordination ledger

## Authority

- Glass: initial freeze HEAD `1be91765652fbb2b47710900f8580d699a068917`; current re-pin
  `562db5c7429373220a4f1ec4e67470d65fcdbd91`
- Live Q sci: `/Users/mkbabb/Programming/.p-totality/sci`, HEAD observed `3bae9de1`
- Atlas authority reported by the sibling task: `a040f88`
- The older `/Users/mkbabb/Programming/sci-report` checkout is archaeology, not live-Q authority.

Every ship-time census and visual measure must be rerun against pinned clean candidates. Dirty live
probes retain their defect mechanism but are RED discovery only.

## Accepted producer edges

### G3 → W-BACKDROP-COMPOSITED-SIGNAL / MATERIAL W2

Keep producer RED, but strike the proposed second attenuation/opacity axis. The existing observer and
luma→tint register remain the intended axis, but the producer currently loses the source before the
sampler: GlassDock always supplies a getter, and an absent consumer canvas becomes configured-live
intent resolving null/unavailable instead of auto-discovery or static sampling. Live Atlas passes no
`backgroundCanvas`, and its Aurora has no `data-glass-field-canvas` marker. MATERIAL W2 must preserve
undefined-vs-configured source semantics and repair the underlay compositing; Q must supply or mark the
real canvas. Q's measured atmosphere↔dock opacity pair is not evidence that the luma loop worked.

### G4 → DataTable / PERF W2

Glass owns stable, idempotent per-key row-ref notification, current row/index metadata, explicit
handler handoff, and dead-key cache eviction. Atlas owns the downstream performance
remeasure because its `SourceDataBrowser` constructs row observers. The producer gate asserts callback
lifecycle; Atlas telemetry asserts observer construction. Neither side substitutes one for the other.

### G5 → SegmentedTabs / IOS FINAL W5

Glass owns a declared-size empty adornment cell plus a dedicated active-only decorative slot; live Q
consumes it in `dashboards/home/gallery/GalleryView.vue:167-194`. The measured active change is
662.6875→778.625px, with all option widths equalizing because the active-only CompletionSeal changes
intrinsic max-content. The reservation mounts no inactive seal/label/animation, works in tooltip/plain
branches, and is not an arbitrary-slot-width promise. Q removes the Gallery seal's `label`: the
containing toggle already exposes its visible label and `aria-pressed`, while the nested status/live
announcement duplicates the change. This does not change CompletionSeal semantics for unrelated
consumers such as CategoryHomeView. No consumer fixed-width shim.

### G6 → compact DockControl hit floor / A11Y W2-F

Atlas mounts the real `<DockControl compact>` as the membrane enlarge action. Glass currently has no
producer-backed ≥44×44 coarse target: the later compact rule resets width/height to auto, min-width to
0, and padding to `.25rem`; the standalone coarse floor explicitly excludes compact, while the existing
transparent hit-slop matches trigger families rather than plain DockControl.

Add a compact-control clause beside A11Y W2-F. The cure may use a self-limiting transparent hit-slop or
an honest hit-cell floor, but must keep compact paint and prove no overlap with neighboring controls.
Q uses no fixed consumer size or private selector.

### W-DOCK-SAFE-FRAME — investigation, posture unresolved

The collision is platform-wide across `/sci`, `/usf`, `/ecf`, `/demand`, `/speedtest`,
`/vft-germination`, and `/usf-integrity`. Keep the zero-intersection producer invariant, but do not
select a posture. Live Atlas uses one fixed vertical top-left rail at every viewport, and Q has no
owner ruling authorizing the phone bottom-bar prior. GF-DOCK W9 therefore prototypes the actual tree
with (a) the current crest→sheet rail in an adjacent side slot and (b) a bottom-row family only after
owner authorization. Gate any Glass export and Atlas adoption on an injected ScrollRoot migration.

Atlas's external simplified prototype supplies only a topology falsifier: persistent fixed-footer/root
scroll produced 9 content-hit/dock intersections at both 390×844 and 1440×900, while the adjacent
viewport-frame/content-port family produced 0 at both widths and revealed the final focused action with
0 dock overlap. The latter neither models the current vertical rail nor authorizes a bottom dock; it is
not receiver truth or production GREEN.

Consumer proof covers every route, arbitrary continuous positions, true coarse touch and width-only
fine-pointer contexts, active/focusable narrative regions, clipping ancestry, safe area, PRM, and one
dock landmark composing filter/nav/G-CLOSE. Snap stops, padding, and scroll-margin are insufficient.
Glass exposes the structural port. Atlas's small adapter exposes that element as the `scroll`/`scrollend`
source plus position, extent, client-size, and scroll operations; native CSS timelines and ordinary
IntersectionObserver remain native and are re-proved through the real tree.

### SCI-ATLAS-CONSUMER-REACH-01

Every embedded visualization receiver names its exact mount, allocated height, every scroll owner,
clipping ancestors, deepest reachable control, mobile inspector/drawer reach, keyboard focus reveal,
390/1440 rest/interaction/mid/settle frames, and PRM. Zero document overflow is non-probative.

## Rejected or consumer-local edges

- The live-Q MetricBadge migration break is refuted. Q already pins Glass 7.0.0 and uses `/metric`.
  ECF's orphan `.metric-badge__label` CSS is consumer cleanup, not a producer contract.
- Drawer attr-drop is refuted by a fresh accessible dialog probe. Q deletes the stale comment.
- Atlas FOLD-1 has a production reader but still arbitrates two projections and duplicate gear mounts.
  That remains one Atlas composite-projection cleanup, not a Glass primitive.
- Fine-pointer 390 target-size measurements do not yet establish a Glass defect. Q remeasures true
  coarse touch before classifying producer versus consumer.
- Keyframes' missing Glass devDependency belongs to the keyframes manifest/lock and clean-install gate.

## Ship sequence

1. Glass producer contracts land and publish from a clean candidate.
2. Keyframes fixes its declared devDependency after the Glass version exists.
3. Atlas migrates ScrollRoot before consuming safe frame.
4. Atlas/Q repins Glass, adopts G4/G5/G3 as applicable, removes consumer debt, and reruns its complete
   receiver matrix.
5. Both ledgers record exact commits, versions, clean status, worktree digests, and routed remainder.

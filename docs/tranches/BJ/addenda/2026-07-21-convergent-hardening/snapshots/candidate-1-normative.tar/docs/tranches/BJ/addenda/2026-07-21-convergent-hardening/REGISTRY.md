# Reduced retained registry

No row below is permission to edit product source during this formation cut. “Owner” names where a
future implementation belongs. Existing owners are amended rather than duplicated.

## Execution-control and contract rows

| id | disposition | owner | born-RED / acceptance |
| --- | --- | --- | --- |
| R-MODEL-LAW | retain, active immediately | execution lead | Every future seat declares Sol x-high for design/judgment or Luna x-high for bounded mechanical work. Historical receipts retain actual labels. An undeclared seat fails the launch record. |
| R-IOS-W0-TRUTH | refute omission; clarify cursor | execution lead / IOS FINAL | `FINAL.md` defines W-0 as opening verification, and `W0-PAINT-LEDGER.md` plus commit `1d0c17c6` prove it already ran (6 PASS / 1 DEFER / 0 FAIL). P-EX3 correctly schedules W-1…W-7 as the remaining set, with W-7 carrying the deferred tail. |
| R-TRUTH-CURSOR | merge | execution lead | Reconcile all 92 rows, bank limited historical challenge coverage, and index exact π debt. A touched row without two critics and evidence stays non-DONE. |
| R-PARK-W7 | retain blocker | owner/lead | REDUCTION W7 cites a nonexistent “ASK A4.” GREEN requires a new frozen ASK row or an explicit lead disposition; no executor infers one. |
| R-GREENFIELD-ASK-TRUEUP | retain dated routing | execution lead / ASK surface | Senior GF-AURORA records the ink fork CUT, but absent an owner mark ASK-20 remains an authority-conflict park; Q-AURORA-QUARTET is separately open. Senior GF-BLOB replaces chrome-default and WGPU-delete premises with technicolor-vs-warm plus thinking/grab questions. Dated brackets discharge ASK-22 and replace ASK-21 without rewriting frozen text; ASK-28…31 carry the new live user choices and park only their named slices. |
| R-PUBLIC-RIM | retain, clean break | `BJ.W-PROGRESS-RIM-REPLACE` (FM W2) close / 8.0 release | Published v7 exposes `coverage`/`ScrollProgressRimCoverage`; current 7.0.0 source replaces them with `orientation`/`ScrollProgressRimOrientation`. GREEN is an explicit 8.0 removal/addition, API diff, migration note, fresh consumer census, and no 7.x alias. |
| R-BOOT-GATE | retain, split | GATES W1 / PERF gate owner | Normal tests currently pay a stale whole-tree build-freshness arm. GREEN splits a source-import unit arm from an explicit command that builds fresh `dist-demo` before parser/ceiling assertions. Mutating either source imports or the built ceiling must bite. |
| R-SHIPPED-MATERIAL | keep and prioritize | MATERIAL W7 then W8 | W7 restores orphaned glass-chip/glass-atom CSS; W8 replaces the WebKit `@supports` lie with the runtime latch and video-path proof. These are shipped defects, not discretionary polish. |

## Graph, performance, and material rows

| id | disposition | owner | born-RED / acceptance |
| --- | --- | --- | --- |
| R-DAG-TRUEUP | merge into live COLOCATION W3 Form-A audit; RF-7 remains historical input | `BJ.W-COLO-3` | Current authority: 535 modules; 1,297 complete directed pairs = 1,042 runtime + 255 type. The definition includes static imports/exports, literal dynamic imports, and TypeScript `ImportTypeNode` edges (the 1,297th edge is `Blob.vue`'s inline renderer-status type); nine all-edge SCCs; two static-runtime SCCs (`Alert`, `Badge`). Publish parser definitions, remove the fictitious dock cycle, record the selection→tabs inversion, and make stale generated artifacts fail visibly. Do not mint a product gate or regenerate unrelated similarity output merely to move a timestamp. |
| R-DATATABLE-REF | merge into PERF W2 | DataTable producer, then Atlas PERF consumer | Inline refs at `DataTable.vue:289,412` cause external `rowRef` null/non-null churn on unrelated patches. Cache one closure per stable row key with mutable current row/index metadata and make element notification idempotent. Reorder or same-key row replacement updates metadata without inventing a DOM lifecycle; a later real unmount uses current metadata. Replacing the public `rowRef` handler performs one explicit old-null/new-element handoff for mounted rows. Prune dead-key cache records after unmount. Tests cover unrelated rerender, reorder, same-key row replacement, handler replacement, add/remove/key replacement, and eviction; only actual lifecycle/handoff may reconstruct Atlas observers. |
| R-TABS-ADORN | retain in IOS FINAL W5 | SegmentedTabs producer, then live-Q Gallery consumer | Live Q measured 662.6875→778.625px when an active-only CompletionSeal changes intrinsic width. Add a bounded decorative reservation contract, not an arbitrary-slot promise: an explicit adornment inline-size creates one empty `aria-hidden`/inert cell in every option, while a dedicated active-adornment slot mounts content only for the active option. Q moves the seal into that slot without `label`; the button's visible label + `aria-pressed` already name and expose selection, so the current nested status/live label is duplicate verbosity. No inactive seal or animation exists. Tooltip/plain branches share the renderer and cell. This ruling is consumer-local—other CompletionSeal uses keep their independent semantics. Removing the inactive cell reintroduces width shift. A consumer fixed-width shim is forbidden. |
| R-COMPOSITED-SIGNAL | merge into MATERIAL W2 | backdrop sampler / GlassDock | Two producer failures compose. `backdropLuminanceSample.ts:178-184` composites translucent canvas pixels over hardcoded white. Separately, `GlassDock.vue:101-109` always supplies a getter: when the consumer passes no canvas, that getter still declares live intent but resolves null, bypassing auto-discovery and static sampling and writing `unavailable`. Preserve undefined-vs-configured source semantics, prove auto-discovery/static parity, then composite with the real opaque underlay/effective opacity and reuse the existing luma→tint axis. The real Atlas receiver must supply or declaratively mark its canvas before its readback counts. Restoring the null getter or white underlay must fail. No second attenuation/opacity axis. |
| R-COMPACT-HIT-FLOOR | retain as new clause beside W2-F | `BJ.W-A11Y-LINKAGE` W2-F | A plain `<DockControl compact>` receives `.dock-icon-button--compact`, whose later rule resets width/height to `auto`, min-width to `0`, and padding to `.25rem`; the coarse standalone floor excludes compact and trigger hit-slop selectors do not match it. The actual Q membrane enlarge mount must expose an honest ≥44×44 coarse hit region while paint remains compact. Restoring the auto/0/.25rem no-floor mechanism must fail. |

## Visual and responsive owner amendments

| id | disposition | owner | acceptance |
| --- | --- | --- | --- |
| R-RESPONSIVE-REACH | merge, reopen false-green | STORY W6 audit; GF-AURORA W7 cure | The 0/99 audit proved document overflow, not clipped-control reach. On `/substrates/aurora`, fixed height + `scroll-mode="never"` can leave the mobile controls row with zero usable height behind `overflow-hidden`. GREEN records the allocated height, scroll owners, clipping ancestors, deepest control, sequential-focus reveal, and clean 390/1440 captures. V-A95 remains separate under GF-AURORA W6. |
| R-DOCK-EXPOSURE | merge | GF-DOCK W3 then W9 | At narrow width the tab port can collapse to a sliver while remaining technically scrollable. Click, keyboard, direct URL, history, programmatic route, and category changes must synchronously commit and fully expose the current item; structural peek/lip appears only when content is hidden. |
| R-HIERARCHY | merge | STORY W1 policy → W4 rollout | Parsed Vue templates contain 269 real `StorySection` instances and four `level` bindings across three routes. Page type/section role supplies visual defaults; semantic heading order remains explicit. Prove one representative of every page type at 390 and 1440. |
| R-PREVIEW-AUTHORSHIP | merge | STORY W5 | `SectionPreviewCard` currently renders a rounded, inset, bordered media well inside a bordered outer link in CatalogLanding, SectionLanding, and foundations/intro. The outer link is the one card; the media well becomes an unbordered aperture. CatalogLanding owns optional category-intent state emitted equally by card hover and focus, so variables cascade from the article into its existing Optical Bench signature; cards cannot write variables upward. At one-column/mobile, the focused card carries the locally visible hue/caustic response because the bench may be offscreen. No rename requirement, extra card/canvas/WebGL, or idle loop; PRM changes state instantly. |
| R-COPY-TAIL | verification tail | STORY W2 | Fail user-facing hero/lede copy that describes implementation instead of outcome, choice, or use. Public API terms on an API-learning story are allowed. No phrase-count gate or technical-word ban. |
| R-ROUTE-DIRECTOR | merge | STORY W7 with-or-before PERF W4 | Classify navigation at the single initiation service, not only `pushRoute`: in-app link, dock, and programmatic paths use the director; history/pop and direct initial load are explicitly instant unless a reliable wrapper is proven. Descend pairs outgoing preview→incoming header; ascend pairs outgoing header→incoming preview; lateral/jump uses one restrained root transition. Busy semantics arm immediately; visual pending avoids fast-route flash and clears on readiness. Tests cover every initiation class and PRM. |
| R-SCROLL-DIRECTOR | merge, no new wave | REDUCTION W9; STORY W7 fallback only if ASK-4 declines | `/motion/scroll` has 13 sections, 9 headings, and four nested vertical ports. Reduce to one documented scroll-animation register, one narrative progression, and at most one independently scrolling port visible at a time. Preserve focus and PRM; animate compositor-safe properties, prefer CSS timelines, and budget any unavoidable coalesced main-thread reader rather than claiming a zero-JS compositor path. |
| R-PI-ROUTE | governance addendum | every visual owner | Capture changed component plus real enclosing route at 390×844 and 1440: rest, hover, keyboard focus, onset, representative mid-flight, settle, and PRM. Assert visible focus, no clipping/CLS, one dominant moving object, and state parity without PRM travel. Use readiness hooks, not arbitrary sleeps. |

## Conditional cross-repository producer contract

### R-DOCK-SAFE-FRAME — contract investigation under GF-DOCK W9; no selected posture

Glass's demo hand-builds one structural family in `AppShell.vue:222-271`: a viewport frame, one
`min-height:0` content scroll region, and a normal-flow adjacent BottomDock. It proves that family is
possible; it is not a second consumer of Atlas's posture. Live Atlas instead mounts the same vertical,
fixed, top-left rail at every viewport (`Dock.vue:23-25,86-90,226-245`; `Dock.css:30-38`) and has
reproduced collisions across all seven dashboards at 390×844. Q has no owner ruling authorizing a
phone bottom-bar change: `RATIFICATION.md` dial 13 and `W-MEMBRANE-IMPL.md` keep the current
crest→sheet posture pending an explicit decision.

GF-DOCK W9 owns only the Glass-side contract investigation inside the 92-row map. It may own a public
extraction and demo repoint later if an actual-tree prototype wins and Atlas can co-land. The Atlas
shell owner owns its posture decision, external adapter, and production proof.

The invariant is reusable and additive: a scroller-agnostic viewport frame exposes a real content
port and a structurally adjacent dock region so no persistent dock intersects active content. The
topology is not selected. Prototype the actual Atlas tree as (a) its current vertical rail in an
adjacent side slot while preserving crest→sheet behavior and (b) a `100dvb` bottom-row family with
`minmax(0,1fr) auto` only after explicit owner authorization. Both need `min-block-size:0`, safe-area
accommodation, and a port Atlas can map to scroll/scrollend events, metrics, and operations. The frame
does not own filter/nav/G-CLOSE props; Atlas composes them inside one dock landmark.

Do not implement or export either family until Atlas migrates every window/document reader to one
injected ScrollRoot and can co-land as a consumer. A bottom-footer prototype does not authorize a
posture change, and preserving the current fixed overlay cannot satisfy the invariant by assertion.

Born RED: the external simplified prototype measured 9 content-hit/dock collisions at both 390×844
and 1440×900 for persistent fixed-footer/root-scroll topology, versus 0 at both widths for one
adjacent bottom-row family. Those numbers falsify overlay avoidance but do not select Atlas posture.
GREEN requires a pinned actual-tree result for the authorized family across all seven routes,
arbitrary continuous positions, coarse touch and width-only fine-pointer contexts, zero intersection
with visible/focusable H1/H2/stat/prose, focus/anchor clearance, safe-area variation, and PRM parity.
Removing the selected adjacent track, removing `min-block-size:0`, or redirecting a migrated reader to
`window` must fail. Padding, scroll-margin, and snap-stop-only tests are non-probative.

## External-only row

`keyframes.js` imports Glass throughout demo/tooling while its manifest omits Glass and a local install
reports it extraneous. That is a keyframes manifest/lock devDependency and clean-install obligation.
Glass records the outbound receipt and publishes first; it does not edit the keyframes tree or mint a
Glass source wave.

## Execution order

1. Apply the model law, preserve the banked-W-0/remaining-W-1…W-7 cursor truth, and keep REDUCTION W7 explicitly blocked.
2. Bank the 92-row truth cursor and paint-debt index.
3. Split the boot gate, true up the DAG instrument, and declare the ScrollProgressRim 8.0 contract.
4. Execute MATERIAL W7 then W8, followed by the composited-signal amendment.
5. Land DataTable and SegmentedTabs producer contracts before Atlas remeasurement/re-pin.
6. Execute existing STORY, REDUCTION, and greenfield amendments in dependency order.
7. Atlas migrates ScrollRoot; Glass and Atlas then co-land the safe-frame producer/consumer edge.
8. Re-run clean-candidate π, all challenge coverage, release battery, and fresh consumer censuses.

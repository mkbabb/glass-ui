# Rejected, merged, and falsified candidate ledger

This file is normative. A rejected idea may reopen only with new evidence that defeats the cited
falsifier. “Merge” means the defect is real but already belongs to a named tranche row; it is not
permission to mint a parallel wave.

| candidate | disposition | evidence and boundary |
| --- | --- | --- |
| IOS27-MICRO W-0 is silently omitted | **refuted** | `../IOS27-MICRO/FINAL/W0-PAINT-LEDGER.md` and commit `1d0c17c6` bank 6 PASS / 1 DEFER / 0 FAIL. P-EX3 intentionally schedules W-1…W-7; W-7 carries the deferred tail. |
| the senior Aurora spec alone terminally resolves ASK-20 | **rejected** | It records graphite/ink CUT, but that is not an owner mark on the frozen row. W3 remains parked on the authority conflict; ASK-28 separately carries W5's DUSK/DAWN judgment. |
| ASK-21 liquid-metal default option set | **refuted by senior spec** | GF-BLOB says chrome is not a default candidate. ASK-29 asks technicolor-vs-warm-cream without deciding it. |
| ASK-22 blocks a GF-BLOB WGPU-delete wave | **refuted by senior spec/R-1** | W-DELETE-TWIN is struck; W-FINAL carries only the value.js relay addendum. No Blob wave waits on the external delete. |
| live-Q MetricBadge migration break | **refuted** | Live Q pins Glass 7.0.0, imports `/metric`, and has no `MetricBadge`/`metric-badge` consumer. ECF's `.metric-badge__label` is dead consumer CSS to delete, not a producer wave. |
| Drawer drops title/description attributes | **refuted** | A fresh `/speedtest` touch probe rendered the teleported dialog with named `aria-labelledby`, `aria-describedby`, and full text; `DrawerContent.vue:46-48,180-185` binds attrs. Delete the stale Atlas comment. |
| live dock↔dropdown-menu runtime cycle | **refuted** | The current graph reaches leaf `dockContext` with no back-edge. The actual static runtime barrel cycles are Alert and Badge; route their true-up to `BJ.W-COLO-3`. |
| product-wide graph gate / taxonomy flattening | **rejected** | The graph is architecture evidence. Publish parser definitions and stale-stamp truth under COLOCATION W3; do not add ordinary product-test tax or rewrite unrelated similarity output. |
| new scroll-story wave | **merged** | `/motion/scroll` has 13 sections, nine headings, and four nested vertical ports. REDUCTION W9 owns the family reduction; STORY W7 is fallback only if ASK-4 declines. |
| split easing because of LOC | **rejected** | Size alone supplies no consumer, behavior, or contract defect. ASK-11 governs demo privatization; a future split needs independent ownership and born-RED evidence. |
| Handmark/Dock nested-frame rider | **refuted** | The duplicate rounded media well is authored by shared `SectionPreviewCard.vue:23-58,76-92`, so STORY W5 owns one-card grammar across catalog/section landings. |
| Aurora clipped controls are V-A95 | **refuted** | Fixed height plus `scroll-mode="never"` is a receiver-reach failure under GF-AURORA W7/STORY W6. V-A95 remains a separate retire-or-confirm instrumentation rider under GF-AURORA W6. |
| technical-word or phrase-count copy gate | **rejected** | User-facing copy is judged by outcome, choice, and use. Public API terms remain legitimate on API-learning stories; STORY W2 owns the narrow tail. |
| second dock attenuation/opacity axis | **rejected** | The existing luma→tint register is the intended axis. MATERIAL W2 first repairs configured-source plumbing and real-underlay compositing; Q's `--glass-opacity-dock` pair is not proof that sampling worked. |
| G3 is already produced | **refuted** | `GlassDock.vue:101-109` turns absent input into a live null getter, bypassing discovery/static sampling; `backdropLuminanceSample.ts:178-184` hardcodes white. Live Atlas supplies no source/marker. |
| fixed-width Gallery tabs shim | **rejected** | Active-only CompletionSeal changes intrinsic max-content. Glass supplies a structured reservation in both SegmentedTabs branches; live Q does not freeze a consumer width. |
| arbitrary SegmentedTabs slot-width guarantee | **rejected** | G5 reserves a declared adornment cell, not arbitrary slot content. Unbounded slot geometry is not a stable producer contract. |
| make CompletionSeal globally decorative | **rejected** | Only live Q Gallery's seal is redundant inside a labelled `aria-pressed` toggle. Standalone consumers such as CategoryHomeView retain independently adjudicated labels/status semantics. |
| Glass constructs Atlas's per-row observers | **refuted** | DataTable owns external row-ref callback stability; Atlas constructs downstream observers. G4 proves idempotence by key+element, then Atlas separately remeasures observer constructors. |
| every narrow fine-pointer target is a Glass defect | **rejected** | Width-only emulation does not prove coarse hit geometry. G6 retains only the exact plain compact DockControl gap because its selectors exclude both coarse floor and trigger hit-slop. |
| padding, scroll-margin, or snap stops make a fixed dock safe | **refuted** | They change endpoints, not arbitrary continuous overlap. The simplified Atlas prototype reported 9 collisions at both widths for persistent overlay topology. |
| bottom-row safe frame is selected receiver truth | **refuted** | Live Atlas uses a vertical top-left rail at every viewport, and Q's dial 13 remains owner-pending. The 0-collision simplified footer prototype is a falsifier only; GF-DOCK W9 must use the actual tree and cannot select bottom posture without authorization. |
| dirty moving-tree screenshots prove release GREEN | **rejected** | HMR and moving commits make them discovery evidence only. Ship proof records commit, clean/dirty state, worktree digest, and reruns on a pinned candidate. |
| speculative standalone Optical Bench component | **rejected** | Reuse the existing catalog meniscus/dot signature as the STORY W5 Refractive Focus treatment. No new card, canvas, WebGL surface, idle loop, or mandatory rename. |
| remote-only Optical Bench response | **rejected** | A card cannot cascade variables to an earlier sibling, and the bench can be offscreen in the one-column layout. CatalogLanding owns state; the active card supplies the mandatory mobile-local response. |
| universal animated history/direct-load route path | **rejected pending proof** | Only initiations that can be wrapped before navigation use the director. History/pop and direct initial load stay instant unless a reliable wrapper preserves restoration and focus. |

# BJ convergent hardening addendum — goal and freeze contract

**State:** FROZEN-CANDIDATE-1 · RED · formation only  
**Goal opened:** 2026-07-21 21:17:39 EDT  
**Earliest allowed completion:** 2026-07-23 21:17:39 EDT  
**Repository authority:** initial pass/freeze-0 HEAD `1be91765652fbb2b47710900f8580d699a068917`;
freeze-1 re-pin HEAD `562db5c7429373220a4f1ec4e67470d65fcdbd91`

The checkout was moving while the discovery probes ran. Before this addendum was written, the
foreign dirty patch digest was
`eab5d7ea0f5bdc7cd3b24caf36c2e2b362f0f14586e4141da17740752ddc64de` and the foreign untracked-path
digest was `89b41d185857b7378aaf8e0e9c7e81e53b689904131371483467a362d837d44f`. Those files belong to another
active task. They are evidence context, not this addendum's changes.

## Objective

Challenge and harden the whole live BJ execution tranche—every in-flight, source-touched, parked,
and untouched row—then leave a smaller executable addendum that improves visual authorship,
affordance, motion, component boundaries, scroll choreography, responsive reach, material truth,
and cross-repository consume edges without duplicating existing waves.

This addendum executes the two attached Écoute-moi/convergent-loop prompts under these substitutions:

- **Sol x-high** owns design, judgment, audit, critique, orchestration, and paint taste.
- **Luna x-high** owns bounded mechanical work against a written contract.
- Historical Fable/Opus labels remain unchanged where they are receipts of work that actually ran.
- An undeclared or inherited model is not an acceptable execution seat.

## Boundaries

- This is a formation and adversarial-audit cut. It changes tranche documents, not product source.
- Existing dirty source, tests, evidence, and untracked audit files are foreign-owned and preserved.
- No compatibility shim, consumer-local masking fix, speculative public surface, or second material
  axis is authorized here.
- A pending ASK is a deliberate park, not a defect. An unrouteable or silently unscheduled row is a
  defect.
- A live visual probe from a dirty moving tree discovers RED; it cannot prove release GREEN.
- Cross-repository trees remain read-only. Glass producer needs are routed here; Atlas/keyframes
  consumer work remains with its repository owner.

## Exit contract

The goal remains active until all of the following are true:

1. The exact 92-row authority is preserved: 48 BJ band waves, 35 greenfield waves, 8 IOS27-MICRO
   waves, and the 1 BI carry.
2. Every row is classified as source-touched, untouched, parked, blocked, or DONE-with-evidence;
   source-touched is never treated as DONE. `ROW-CHALLENGE-MATRIX.md` records the row-grain challenge
   receipts and gaps; aggregate family prose is not a substitute.
3. The entire roster has survived at least three adversarial challenges. Because the first discovery
   round did not carry an explicit model assertion, a fresh post-freeze Sol x-high challenge is still
   required even though three analytical rounds have already run.
4. The frozen addendum then survives two consecutive clean audits with no intervening plan edit.
5. Every retained implementation row names an owner, a born-RED proof, a mutation bite, a consumer,
   and its dependency order. Every rejected row is present in the normative `REJECTIONS.md` ledger
   with the evidence that prevents it from reopening as product work.
6. Every visual owner banks clean-candidate component and enclosing-route evidence at 390×844 and
   1440, including keyboard focus, interaction onset, representative mid-flight, settle, and PRM.
7. Glass/Atlas asks are reconciled against live-Q authority, and all implementation/export work that
   depends on Atlas ScrollRoot migration remains gated until that prerequisite lands.
8. At least 48 actual hours have elapsed from the goal-open timestamp above.

## Current result

Three aggregate pre-freeze analytical passes reduced the candidate set, but the 92-row matrix proves
that many rows received inventory coverage rather than three row-specific judgments. Candidate 1 is
therefore frozen RED so three independent Sol x-high whole-roster audits can challenge the same bytes.
The plan also remains RED on ASK-20's owner-authority conflict, REDUCTION W7's missing disposition,
the exact-candidate post-freeze challenge, two consecutive clean frozen audits, all implementation/
evidence work in `REGISTRY.md`, and the 48-hour floor.

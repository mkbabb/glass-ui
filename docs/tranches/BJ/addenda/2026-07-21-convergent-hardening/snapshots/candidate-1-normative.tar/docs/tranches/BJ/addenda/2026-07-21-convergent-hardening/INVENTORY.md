# Exact tranche inventory and execution truth

## Governing arithmetic

The live execution set is **92 rows**:

- 48 BJ band waves
- 35 greenfield waves
- 8 IOS27-MICRO waves
- 1 BI carry

The prior approximate 91-row/17-touched language is struck. At initial HEAD `1be91765`, 18 rows were
source-touched. The re-pin to `562db5c7` adds A11Y W5-C's dock disabled-state follow-on, so the current
truth is **19 source-touched** and **73 untouched or parked**. This addendum marks no new row DONE.

## The 48 BJ band waves

| band | rows |
| --- | --- |
| A11Y (5) | `BJ.W-A11Y-STATE`, `BJ.W-A11Y-LINKAGE`, `BJ.W-A11Y-CONTRAST`, `BJ.W-A11Y-LIVE-REGIONS`, `BJ.W-A11Y-ROVING-RULINGS` |
| COLOCATION (3) | `BJ.W-COLO-1`, `BJ.W-COLO-2`, `BJ.W-COLO-3` |
| DOC-TRUTH (1) | `BJ.W-DOC-TRUTHUP` (`BJ.W-IDIOMS-COLOCATION-REWRITE` is ceded, not a second wave) |
| FEEDBACK-MOTION (7) | `BJ.W-TOAST-DIALOG-PARITY`, `BJ.W-PROGRESS-RIM-REPLACE`, `BJ.W-FEEDBACK-MOTION-TUNE`, `BJ.W-ALERT-IDIOM`, `BJ.W-IDLE-BREATH`, `BJ.W-PAGER-DOT-MORPH`, `BJ.W-SHEET-MOTION-DEBT` |
| GATES (4) | `BJ.W-GATE-COLLAPSE`, `BJ.W-PIXEL-FLOOR-CI`, `BJ.W-STATIC-HYGIENE`, `BJ.W-RAMP-RESET` |
| MATERIAL (8) | `BJ.W-RADIUS-ROLE`, `BJ.W-BLUR-LADDER`, `BJ.W-GRADED-BACKDROP-JUDGE`, `BJ.W-TRACK-DRY`, `BJ.W-ARISTOTLE-PROPORTION`, `BJ.W-TYPE-CODEMOD`, `BJ.W-CSS-CLOSURE-RESTORE`, `BJ.W-REFRACT-LATCH` |
| PERF (4) | `BJ.W-BOOT-DIET`, `BJ.W-SHELL-FIELD-GOVERN`, `BJ.W-DEFERRED-PAINT`, `BJ.W-ROUTE-PENDING` |
| REDUCTION (9) | `BJ.W-REDUCE-PROPDIET`, `BJ.W-REDUCE-CARD`, `BJ.W-REDUCE-DELETE`, `BJ.W-REDUCE-CROSSREPO-GATED`, `BJ.W-REDUCE-TIMELINE`, `BJ.W-REDUCE-FEEDBACK-MARK`, `BJ.W-REDUCE-OVERLAY-SURFACE`, `BJ.W-REDUCE-GOO-ENGINE`, `BJ.W-REDUCE-SCROLL-REVEAL` |
| STORY (7) | `BJ.W-STORY-TAXONOMY`, `BJ.W-STORY-COPY-CANON`, `BJ.W-CONFIGURATOR-STD`, `BJ.W-WIDTH-HIERARCHY-TRUTH`, `BJ.W-PREVIEW-CARD`, `BJ.W-RESPONSIVE-AUDIT`, `BJ.W-STORY-TRANSITIONS` |

## The 35 greenfield waves

| campaign | rows |
| --- | --- |
| GF-DOCK (10) | W0 contract lock; W1 census/evidence; W2 detent engine; W3 tap-to-reach/keyboard; W4 selection lens; W5 shape/radius; W6 page transition/no-shift; W7 user-gated fission; W8 posture/continuity; W9 consumer/final |
| GF-HANDMARK (6) | W0 contract lock; W1 voice; W2 surface; W3 choreography; W4 story; W5 consumer/final |
| GF-AURORA (8) | W0 contract lock; W1 Van Gogh primary; W2 oil-pastel; W3 crayon; W4 oil resolution; W5 register/axes/rot; W6 V-A95 retire-or-confirm; W7 consumer/final |
| GF-BLOB (11) | W0 contract lock; W-SHADOW; W-STREAK; W-IDENT; W-SHOW; W-ALIVE; W-MOOD; W-REACT; W-HITTEST; W-TOPOLOGY; W-FINAL |

## IOS27-MICRO and BI

- IOS27-MICRO has **W-0 through W-7**: paint drain, register/token shipping, spine-conductor
  adoption, F4 family, F5 family, novelty adoptions, engagement/breath shipping, and remainders.
- The single carry is `BI.W-ENGAGE-AFFORD`.

W-0 is not a silent schedule omission: its verification ledger was banked at `1d0c17c6` with
6 PASS / 1 DEFER / 0 FAIL before P-EX3. The cursor therefore schedules W-1 through W-7 as the
remaining execution set; W-7 explicitly owns the deferred W-0 row-7 tail.

## The 19 source-touched rows

The commit ledger identifies these as touched, not automatically complete:

1. `BJ.W-STATIC-HYGIENE`
2. `BJ.W-PIXEL-FLOOR-CI`
3. IOS27-MICRO W-1
4. `BJ.W-BOOT-DIET`
5. `BJ.W-DOC-TRUTHUP`
6. `BJ.W-REDUCE-DELETE`
7. `BJ.W-REDUCE-FEEDBACK-MARK`
8. `BJ.W-COLO-1`
9. `BJ.W-REDUCE-GOO-ENGINE`
10. `BJ.W-PAGER-DOT-MORPH`
11. `BJ.W-A11Y-LINKAGE`
12. `BJ.W-TOAST-DIALOG-PARITY`
13. `BJ.W-PROGRESS-RIM-REPLACE`
14. `BJ.W-FEEDBACK-MOTION-TUNE`
15. `BJ.W-REDUCE-PROPDIET`
16. `BJ.W-STORY-COPY-CANON`
17. `BJ.W-CONFIGURATOR-STD`
18. `BJ.W-RESPONSIVE-AUDIT`
19. `BJ.W-A11Y-ROVING-RULINGS` (W5-C follow-on at `562db5c7`)

The early untracked GESTALT A/B reports cover only the first ten execution commits. They are useful
historical challenges, but they neither challenge the later eight rows nor convert any row to DONE.

## Parks and blockers

- The explicit ASK parks remain intentional: ASK-1 through ASK-17, ASK-20, ASK-25, and ASK-27 through
  ASK-31. ASK-27 hard-blocks FEEDBACK-MOTION W5. ASK-28 gates only Aurora W5's DUSK/DAWN death
  clauses; ASK-29 gates the Blob default; ASK-30/31 gate only W-MOOD thinking and W-REACT grab.
  ASK-20 remains a `PARKED-AUTHORITY-CONFLICT`: the senior spec records CUT but no owner mark exists.
  ASK-22 is discharged by the R-1 lead routing, and ASK-21's stale chrome option set is replaced by
  ASK-29. ASK-26 is not a park; it is a veto window whose
  identity decision belongs to MATERIAL W3's paint lane. ASK-18/19 are already owner-resolved,
  ASK-23 is a standing offer rather than a scheduled wave, and ASK-24 is a conditional CI fallback
  that already fired and was ruled.
- REDUCTION W7 is different: it cites “ASK A4,” which exists in neither ruling surface. It remains
  `PARKED-UNROUTABLE` until the owner either mints a new frozen ASK row or records a lead disposition.
- The P-EX2 whole-band rule, P-EX4 greenfield roster references, and BI carry are structurally
  scheduled. Preserve their first-touch K/J annotations and the C7/G1 firing points.

## Challenge coverage

| pass | scope | result |
| --- | --- | --- |
| discovery / challenge 1 | tranche truth, visual gestalt, DAG/consumers | found the 92/18 correction, public ScrollProgressRim break, responsive false-green, visual authorship debt, stale graph, G3/G4/G5, and cross-repo safe-frame need; several claims were intentionally over-inclusive |
| Sol x-high challenge 2 | independent truth, visual, and graph red-team | refuted stale Metric/Drawer claims, pruned Handmark/Dock frame claims, merged scroll direction into REDUCTION W9, corrected G4's producer proof, and reconciled the 535/1,297 graph |
| Sol x-high challenge 3 | fresh global and visual/contract adjudication | proposed an IOS W-0 omission that direct ledger/commit evidence refuted; retained the conditional safe-frame contract, corrected shared preview-card scope, preserved Aurora clipping separately from V-A95, and rejected speculative standalone waves |

The first discovery pass did not carry an explicit model assertion. A post-freeze Sol x-high pass is
therefore mandatory before the three-challenge exit gate may close.

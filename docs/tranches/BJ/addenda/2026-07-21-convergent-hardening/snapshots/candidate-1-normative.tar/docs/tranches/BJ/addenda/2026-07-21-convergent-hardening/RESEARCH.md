# Primary-source research applied to the addendum

- [CSS Scroll-driven Animations Level 1](https://www.w3.org/TR/scroll-animations-1/) supports named
  scroll/view timelines and informs the one-scroll-root, compositor-first scroll director.
- [CSS View Transitions Level 1](https://www.w3.org/TR/css-view-transitions-1/) supports the typed
  route grammar and the rule that one dominant shared object carries descend/ascend.
- [WCAG 2.2: Animation from Interactions](https://www.w3.org/WAI/WCAG22/Understanding/animation-from-interactions.html)
  informs PRM parity for non-essential triggered motion.
- [WCAG 2.2: Pause, Stop, Hide](https://www.w3.org/WAI/WCAG22/Understanding/pause-stop-hide.html)
  bounds persistent ambient movement and prevents “breath of life” from becoming compulsory distraction.
- [WebKit features in Safari 26.0](https://webkit.org/blog/17333/webkit-features-in-safari-26-0/),
  [Safari 26.4](https://webkit.org/blog/17862/webkit-features-for-safari-26-4/), and
  [Safari 26.5](https://webkit.org/blog/17938/webkit-features-for-safari-26-5/) ground the current
  scroll-timeline and backdrop-filter/WebKit evidence rather than assuming Chromium parity.

The standards support progressive, semantic motion. They do not justify nested scrollports, JS motion
fallbacks, or animation as the only carrier of state.


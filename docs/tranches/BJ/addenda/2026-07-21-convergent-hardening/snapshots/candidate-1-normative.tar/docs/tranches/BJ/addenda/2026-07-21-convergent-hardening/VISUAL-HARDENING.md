# Visual hardening riders

This file turns the retained visual findings into the smallest amendments to existing owners.

## 1. Optical Bench — one authored signature, not another surface

The existing catalog already names and renders an Optical Bench meniscus. The defect is that it is
inert and disconnected from the category decisions below it. “Refractive Focus” is the interaction
treatment, not a required product rename:

- CatalogLanding owns optional category-intent state emitted equally by card hover and focus. It
  writes the active hue/caustic variables on the article so they cascade into the earlier sibling
  signature; a card cannot write variables upward or sideways.
- The existing meniscus/dot is reused. No second card, signature block, live component miniature,
  canvas, WebGL context, or idle animation is added.
- The category tile remains the preview→destination shared element. The bench is orientation feedback,
  not a second transition protagonist.
- The focused/hovered card also receives the same restrained local aperture response. That local
  witness is mandatory at 390px, where the earlier bench can be offscreen; remote feedback alone is
  non-probative. PRM commits the selected state instantly with no travel.
- One signature is allowed to be bold. The other category tiles stay quieter so the landing has a
  focal beat rather than simultaneous ambient motion.

This rides STORY W5. It is rejected as a new greenfield or motion primitive.

## 2. One card, one media aperture

`SectionPreviewCard` is shared by CatalogLanding, SectionLanding, and
`demo/stories/foundations/intro.vue`. Today its outer link is a glass card while
`.section-preview-card-preview` adds its own rounded background and inset border. The cure therefore
applies to all three receiver families:

- The outer link is the sole card/surface.
- The preview is an unbordered media aperture with clipping only where authored content requires it.
- Authored/still/identity fallbacks preserve one stable aspect ratio and intrinsic-size reservation.
- The change must not erase necessary paper-canvas boundaries inside a Handmark specimen or transparent
  hairline trays inside DockStage; those were refuted as the same defect.

## 3. Hierarchy is a corpus adoption problem

The parsed Vue template AST finds 269 real `StorySection` elements but only four `level` bindings,
across `curve-gallery`, `springs`, and `configurator`. The capability exists; adoption does not.

- STORY W1 defines the visual default by page type and section role.
- STORY W4 applies it systematically and proves one representative of every page type at both widths.
- `level` remains a visual axis. Heading semantics are checked separately; every section cannot become
  a lower semantic level merely to look smaller.
- Do not reopen STORY W3 wholesale and do not perform a blind 269-site codemod.

## 4. Responsive reach, not viewport containment

The prior W6 sweep measured document overflow and right-edge crossings. It could not see a zero-height
controls row or a 36px internal tab port because both remain inside the viewport.

### Aurora Configurator

`/substrates/aurora` uniquely combines a fixed studio height with `scroll-mode="never"`. At 390px the
Configurator mobile grid can allocate the controls row no usable height while an `overflow-hidden`
ancestor clips the entire remaining control stack. PASS-1 observed 57 clipped controls; that is RED
discovery from a moving tree and must be recaptured on a clean candidate.

GF-AURORA W7 owns the consumer repoint/cure. STORY W6 owns the audit correction. V-A95 is separate:
GF-AURORA W6 performs one screenshot/computed-style-only reverse-drag confirm, then retires the old
black-slab artifact and audits `isolation:isolate` for cargo.

### BottomDock

The current tab port can shrink to an unusable sliver without page overflow. It remains manually
scrollable, so “unreachable” is too strong; the defect is current-item exposure and usable width.

- GF-DOCK W3 owns selection/reach mechanics.
- GF-DOCK W9 owns the real BottomDock adoption.
- Click, focus, direct URL, history, programmatic navigation, and category changes all seat the current
  item synchronously if it would remain clipped beneath an edge.
- Structural peek/lip appears only while content is hidden. PRM seats immediately.

## 5. Motion has one director per event

STORY W7 supplies route semantics; PERF W4 supplies wait feel:

- descend: outgoing selected preview → incoming story header is the one shared moving object;
- ascend: outgoing story header → incoming category preview reverses that pair;
- lateral/jump: a restrained root transition, no competing shared element;
- in-app links, dock actions, and programmatic navigation use one initiation service; browser history
  and direct initial load remain explicitly instant unless they gain a reliable pre-navigation wrapper;
- busy semantics arm immediately;
- a visible pending affordance waits past the fast-route flash threshold and clears on actual readiness,
  never a fixed timeout;
- PRM is an instant state swap with focus, scroll restoration, and announcement parity.

The current `pushRoute()`-only `types:["route"]` 8px rise/fade plus unclassified dock/history/direct
programmatic paths is the born-RED structural proof. No JS animation fallback is added.

## 6. Scroll story becomes an authored progression

`/motion/scroll` has 13 StorySections, 9 headings, and four nested vertical scrollports. REDUCTION W9
already owns the family collapse and is the only implementation owner:

- one documented scroll-animation register;
- one clear 0/25/50/75/100 narrative progression;
- at most one independently scrolling port visible at a time;
- focus reveal and deep links land in the same scroll root;
- CSS timelines remain the preferred path and animated properties stay compositor-safe. The current
  coalesced `--pin-t` reader proves that “compositor-only” cannot mean zero main-thread work; any
  unavoidable reader gets an explicit bounded budget. Unsupported/PRM is readable without travel.

If ASK-4 declines consolidation, STORY W7 is the existing fallback for remaining narrative/transition
debt. No new directorial wave is minted.

## 7. Evidence floor

For every changed visual component, capture both the component and its enclosing real route at 390×844
and 1440 in these states: rest, pointer hover, keyboard focus, interaction onset, representative
mid-flight, settled, and PRM interaction/settle. Route work includes one descend/ascend pair and one
lateral/jump pair.

Acceptance asserts visible focus, no text/control/card clipping, zero layout shift caused by the
motion, one dominant moving object, and PRM state/affordance parity without travel. Mid/settle samples
are driven by readiness or transition hooks, never arbitrary sleeps. All release evidence records
commit, clean/dirty status, and worktree digest.

Route evidence covers link, dock, programmatic, history, and direct-load initiation. Preview evidence
covers CatalogLanding, SectionLanding, and foundations/intro; the catalog also proves that keyboard
focus produces a locally visible response at 390px when the Optical Bench is outside the viewport.

# Born-RED and mutation-proof gate plan

These are acceptance probes, not a request to add a standing gate for every row. Cheap, user-observable
regressions may become tests; one-time visual and architecture proofs remain evidence.

| contract | born-RED proof | mutation bite | GREEN evidence |
| --- | --- | --- | --- |
| ScrollProgressRim 8.0 | a v7 consumer compiles with `coverage`; current source/types do not | restore undeclared replacement or omit migration | API diff, migration, fresh consumer census, clean 8.0 compile fixtures |
| boot split | normal tests inspect stale `dist-demo` after unrelated source edits | skip fresh build or plant oversized/unparsed built asset | source arm independent of dist; explicit build arm rebuilds and bites |
| DAG truth | checked artifact reports 354/975 and false dock-cycle prose | add/remove inline import-type or dynamic accent edge | parser definition plus 535/1,297 and both SCC modes; stale stamp fails |
| DataTable row refs | unrelated rerender emits external null/non-null row callbacks | remove stable closure/element guard, retain stale metadata, skip handler handoff, or leak dead-key cache | table/card cases cover rerender, reorder, same-key row replacement, handler replacement, add/remove/key replacement, and eviction; Atlas observer constructors change only for real lifecycle/handoff |
| SegmentedTabs adornment | active CompletionSeal changes live-Q strip 662.6875→778.625px and its nested live label duplicates the toggle state | remove inactive reservation cell, mount content in inactive cells, or restore the Gallery-only seal label | declared cell preserves button/strip geometry in tooltip/plain branches; only one decorative Gallery seal exists, plays, and is absent from the accessibility tree; unrelated CompletionSeal consumers retain their semantics |
| composited signal | a missing dock canvas is converted into a configured null getter/unavailable loop; translucent pixels are then composited over hardcoded white | restore the null-getter plumbing, white underlay, or ignore effective opacity | undefined/configured/auto-discovered/static source matrix plus analytical 1×1 results; real Atlas source witness and live readback differ correctly without a new opacity axis |
| compact DockControl hit floor | compact override resets width/height to auto, min-width 0, padding .25rem; coarse floor excludes it | restore compact auto/0/.25rem without hit floor | actual Q membrane mount, rest/collapsed/expanded, coarse/fine: paint vs hit rect, four-corner `elementFromPoint`, focus reveal, toggle name/state, neighbor non-overlap; coarse hit ≥44×44 |
| Aurora reach | fixed-height `scroll-mode="never"` leaves controls behind a zero-height/clipped row | restore zero-height ancestor or hidden overflow | every expected control is sequentially focusable and can intersect its valid scrollport at 390/1440 |
| BottomDock exposure | current item is mounted but partly/fully outside a narrow internal port | disable route-driven recenter | click, keyboard, URL, history, programmatic, category paths fully expose current item |
| heading rollout | 4 of 269 StorySections bind visual level | return page-type default to one flat rung | representative page type matrix has explicit visual hierarchy and valid semantic order |
| one-card grammar | shared preview adds a second rounded/inset boundary inside outer card | restore inner boundary | outer link is sole card; aperture remains stable across tile fallbacks in CatalogLanding, SectionLanding, and foundations/intro |
| route director | `pushRoute` alone dispatches one generic `route` type while dock/history/direct programmatic paths are unclassified | bypass the initiation service, reverse the ascent pair, or collapse classes | link/dock/programmatic matrix; explicitly instant history/direct-load paths; readiness-tied settle and PRM parity |
| scroll director | four nested vertical ports and nine equal headings | restore a second simultaneous port or unbounded scroll reader | one visible port/progression with focus/deeplink/PRM parity; compositor-safe property set and measured coalesced-reader budget |
| safe-frame investigation | fixed Atlas vertical rail intersects narrative/focus regions on seven routes; simplified overlay prototype reports 9/9 collisions | after a posture is authorized, remove its adjacent track/min-height or point a migrated reader back to window | pinned actual-Atlas-tree side-slot prototype preserving current posture; bottom-row prototype only after owner authorization; winning family passes all-route continuous/focus/safe-area/coarse/fine/PRM matrix |

## Responsive reach algorithm

Document `scrollWidth` is not enough. The audit records for each expected focusable/control:

1. its bounding rect and allocated block/inline size;
2. every clipping ancestor and that ancestor's client/scroll size;
3. the scroll owner responsible for revealing it;
4. whether sequential focus or the documented programmatic path brings it fully into the scrollport;
5. whether persistent shell/dock hit bounds intersect it after reveal.

Hidden/inert content is excluded only when the product state intentionally makes it unavailable.

## Gate-governance constraints

- Keep user-observable behavior, build, accessibility, public-contract, and cheap pixel-floor tests.
- Do not retain meta-roster counts, hardcoded historical graph seeds, or whole-tree mtime freshness in
  ordinary `npm test`.
- An architecture-only assertion without a product/contract defect remains one-time evidence.
- A mutation that restores the original mechanism must make the proof fail; a screenshot that merely
  looks different is not a mutation bite.
